void anemometre(void) {
  delay(1000);
  
  float windSpeed = (countWind / WIND_FACTOR);
  Serial.print("Vitesse vent: ");
  Serial.print(windSpeed, 2);
  Serial.print(" m/s (");
  Serial.print(countWind);
  Serial.println(" impulsions/s)");
  
  countWind = 0;
}
