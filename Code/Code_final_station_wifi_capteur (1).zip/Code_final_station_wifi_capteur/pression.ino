



void pression(void) {
  float pression    = capteurPression.readPressure(); // Pascals
  float temperature = capteurPression.readTemp();     // °C
  float pression_hPa = pression / 100.0;              // hPa

  Serial.print("Pression    : ");
  Serial.print(pression_hPa, 2);
  Serial.println(" hPa");

  Serial.print("Temperature : ");
  Serial.print(temperature, 2);
  Serial.println(" C");

  Serial.println("---");
  delay(1000);
}