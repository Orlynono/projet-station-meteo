void lumiere(void) {
  delay(1000);
  
  readReg(0x10, buf, 2);
  data = buf[0] << 8 | buf[1];
  Lux = (((float)data) / 1.2);
  Serial.print("Luminosite: ");
  Serial.print(Lux);
  Serial.println(" lx");
}
