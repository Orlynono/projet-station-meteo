<?php
/**
 * index.php — CLM Station Météo
 * Dashboard principal — lit data.json toutes les 5 secondes via fetch()
 * Déposer dans : /var/www/html/meteo/
 */

// Lecture initiale du JSON côté PHP pour le premier affichage (évite le flash)
$data = [];
$dataFile = __DIR__ . '/data.json';
if (file_exists($dataFile)) {
    $raw = file_get_contents($dataFile);
    $data = json_decode($raw, true) ?? [];
}

function val($data, $key, $default = '--') {
    return isset($data[$key]) && $data[$key] !== null ? $data[$key] : $default;
}

// Qualité d'air : libellé selon AQI
function aqiLabel($aqi) {
    if ($aqi === '--') return '';
    $aqi = (int)$aqi;
    if ($aqi <= 50)  return 'Bonne';
    if ($aqi <= 100) return 'Modérée';
    if ($aqi <= 150) return 'Mauvaise pour groupes sensibles';
    if ($aqi <= 200) return 'Mauvaise';
    return 'Très mauvaise';
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CLM Station Météo</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        :root {
            --bg:        #06090f;
            --surface:   #0d1420;
            --border:    rgba(255,255,255,0.07);
            --accent:    #00c9a7;
            --accent2:   #3b82f6;
            --warn:      #f59e0b;
            --danger:    #ef4444;
            --text:      #e8edf5;
            --muted:     #5a6a80;
            --font-head: 'Bebas Neue', sans-serif;
            --font-body: 'DM Sans', sans-serif;
        }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: var(--font-body);
            min-height: 100vh;
            overflow-x: hidden;
        }

        /* Fond animé */
        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background:
                radial-gradient(ellipse 60% 40% at 20% 20%, rgba(0,201,167,0.06) 0%, transparent 70%),
                radial-gradient(ellipse 50% 50% at 80% 80%, rgba(59,130,246,0.06) 0%, transparent 70%);
            pointer-events: none;
            z-index: 0;
        }

        /* Vidéo de fond */
        #background-video {
            position: fixed;
            inset: 0;
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0.07;
            z-index: 0;
        }

        .wrap {
            position: relative;
            z-index: 1;
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 24px 48px;
        }

        /* ── Header ── */
        header {
            padding: 40px 0 32px;
            display: flex;
            align-items: flex-end;
            justify-content: space-between;
            border-bottom: 1px solid var(--border);
            margin-bottom: 32px;
        }

        .logo {
            display: flex;
            align-items: center;
            gap: 16px;
        }

        .logo-icon {
            width: 48px;
            height: 48px;
            background: linear-gradient(135deg, var(--accent), var(--accent2));
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
        }

        .logo-text h1 {
            font-family: var(--font-head);
            font-size: 2.4rem;
            letter-spacing: 2px;
            line-height: 1;
            background: linear-gradient(90deg, var(--accent), var(--accent2));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }

        .logo-text p {
            font-size: 0.75rem;
            color: var(--muted);
            letter-spacing: 1px;
            text-transform: uppercase;
            margin-top: 4px;
        }

        .header-right {
            text-align: right;
        }

        #clock {
            font-family: var(--font-head);
            font-size: 2.8rem;
            letter-spacing: 3px;
            color: var(--text);
            line-height: 1;
        }

        #date-display {
            font-size: 0.78rem;
            color: var(--muted);
            margin-top: 4px;
            text-transform: capitalize;
        }

        /* ── Status bar ── */
        .status-bar {
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 0.75rem;
            color: var(--muted);
            margin-bottom: 28px;
        }

        .status-dot {
            width: 7px;
            height: 7px;
            border-radius: 50%;
            background: var(--accent);
            animation: pulse 2s ease-in-out infinite;
        }

        .status-dot.offline { background: var(--danger); animation: none; }

        @keyframes pulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50%       { opacity: 0.5; transform: scale(0.8); }
        }

        #last-update { color: var(--text); font-weight: 500; }

        /* ── Grid ── */
        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 16px;
        }

        /* ── Carte principale (grande) ── */
        .card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 16px;
            padding: 24px;
            position: relative;
            overflow: hidden;
            transition: border-color 0.3s, transform 0.2s;
        }

        .card:hover {
            border-color: rgba(255,255,255,0.15);
            transform: translateY(-2px);
        }

        .card::before {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 2px;
            background: linear-gradient(90deg, transparent, var(--card-accent, var(--accent)), transparent);
            opacity: 0.6;
        }

        .card-label {
            font-size: 0.7rem;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            color: var(--muted);
            margin-bottom: 12px;
        }

        .card-value {
            font-family: var(--font-head);
            font-size: 3rem;
            letter-spacing: 1px;
            line-height: 1;
            color: var(--card-accent, var(--accent));
        }

        .card-unit {
            font-family: var(--font-body);
            font-size: 1rem;
            font-weight: 300;
            color: var(--muted);
            margin-left: 4px;
        }

        .card-sub {
            font-size: 0.75rem;
            color: var(--muted);
            margin-top: 8px;
        }

        .card-icon {
            position: absolute;
            top: 20px;
            right: 20px;
            font-size: 28px;
            opacity: 0.18;
        }

        /* Cartes colorées */
        .card-temp   { --card-accent: #f97316; }
        .card-hum    { --card-accent: #38bdf8; }
        .card-pluie  { --card-accent: #818cf8; }
        .card-vent   { --card-accent: #34d399; }
        .card-press  { --card-accent: #a78bfa; }
        .card-aqi    { --card-accent: var(--aqi-color, #00c9a7); }
        .card-lux    { --card-accent: #fbbf24; }
        .card-dir    { --card-accent: #fb7185; }

        /* Jauge AQI */
        .aqi-bar-wrap {
            margin-top: 12px;
            background: rgba(255,255,255,0.06);
            border-radius: 4px;
            height: 4px;
            overflow: hidden;
        }

        .aqi-bar {
            height: 100%;
            border-radius: 4px;
            width: 0%;
            transition: width 0.8s ease;
            background: var(--aqi-color, var(--accent));
        }

        /* Boussole direction vent */
        .compass {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 64px;
            height: 64px;
            border-radius: 50%;
            border: 1px solid var(--border);
            margin-top: 8px;
            position: relative;
        }

        .compass-needle {
            width: 2px;
            height: 28px;
            background: linear-gradient(to bottom, #fb7185 50%, var(--muted) 50%);
            border-radius: 2px;
            transform-origin: center center;
            transition: transform 0.8s cubic-bezier(0.34, 1.56, 0.64, 1);
        }

        /* ── Footer ── */
        footer {
            margin-top: 48px;
            padding-top: 24px;
            border-top: 1px solid var(--border);
            text-align: center;
            font-size: 0.72rem;
            color: var(--muted);
            letter-spacing: 1px;
            text-transform: uppercase;
        }

        /* ── Responsive ── */
        @media (max-width: 600px) {
            header { flex-direction: column; align-items: flex-start; gap: 16px; }
            #clock { font-size: 2rem; }
            .card-value { font-size: 2.2rem; }
        }
    </style>
</head>
<body>

<video autoplay muted loop id="background-video" playsinline>
    <source src="fond/meteo.mp4" type="video/mp4">
</video>

<div class="wrap">

    <header>
        <div class="logo">
            <div class="logo-icon">🌦</div>
            <div class="logo-text">
                <h1>CLM MÉTÉO</h1>
                <p>Station en direct &mdash; Terminal STI2D 2025-2026</p>
            </div>
        </div>
        <div class="header-right">
            <div id="clock">--:--:--</div>
            <div id="date-display">--</div>
        </div>
    </header>

    <div class="status-bar">
        <span class="status-dot" id="status-dot"></span>
        <span>Dernière mise à jour capteurs :</span>
        <span id="last-update"><?= val($data, 'timestamp') ?></span>
    </div>

    <div class="grid">

        <!-- Température -->
        <div class="card card-temp">
            <div class="card-icon">🌡</div>
            <div class="card-label">Température</div>
            <div class="card-value">
                <span id="temp"><?= val($data, 'temp') ?></span><span class="card-unit">°C</span>
            </div>
            <div class="card-sub" id="temp-feel">--</div>
        </div>

        <!-- Humidité -->
        <div class="card card-hum">
            <div class="card-icon">💧</div>
            <div class="card-label">Humidité</div>
            <div class="card-value">
                <span id="hum"><?= val($data, 'hum') ?></span><span class="card-unit">%</span>
            </div>
        </div>

        <!-- Pression atmosphérique -->
        <div class="card card-press">
            <div class="card-icon">🔵</div>
            <div class="card-label">Pression atmosphérique</div>
            <div class="card-value">
                <span id="pression"><?= val($data, 'pression') ?></span><span class="card-unit">hPa</span>
            </div>
            <div class="card-sub" id="press-trend">--</div>
        </div>

        <!-- Pluie -->
        <div class="card card-pluie">
            <div class="card-icon">🌧</div>
            <div class="card-label">Pluviométrie</div>
            <div class="card-value">
                <span id="pluie"><?= val($data, 'pluie') ?></span><span class="card-unit">mm</span>
            </div>
        </div>

        <!-- Vitesse du vent -->
        <div class="card card-vent">
            <div class="card-icon">💨</div>
            <div class="card-label">Vitesse du vent</div>
            <div class="card-value">
                <span id="vent"><?= val($data, 'vent') ?></span><span class="card-unit">km/h</span>
            </div>
            <div class="card-sub" id="vent-beaufort">--</div>
        </div>

        <!-- Direction du vent -->
        <div class="card card-dir">
            <div class="card-icon">🧭</div>
            <div class="card-label">Direction du vent</div>
            <div class="card-value" id="dir"><?= val($data, 'dir') ?></div>
            <div class="compass">
                <div class="compass-needle" id="compass-needle"></div>
            </div>
        </div>

        <!-- Qualité de l'air -->
        <div class="card card-aqi">
            <div class="card-icon">🍃</div>
            <div class="card-label">Qualité de l'air</div>
            <div class="card-value">
                <span id="aqi"><?= val($data, 'aqi') ?></span><span class="card-unit">AQI</span>
            </div>
            <div class="card-sub" id="aqi-label"><?= aqiLabel(val($data, 'aqi')) ?></div>
            <div class="aqi-bar-wrap">
                <div class="aqi-bar" id="aqi-bar"></div>
            </div>
        </div>

        <!-- Luminosité -->
        <div class="card card-lux">
            <div class="card-icon">☀️</div>
            <div class="card-label">Luminosité</div>
            <div class="card-value">
                <span id="lux"><?= val($data, 'lux') ?></span><span class="card-unit">lux</span>
            </div>
            <div class="card-sub" id="lux-label">--</div>
        </div>

    </div><!-- /grid -->

    <footer>
        Terminal STI2D 2025-2026 &nbsp;⮕&nbsp;
        Alwyn Le Barbier &nbsp;·&nbsp; Kalvin Hoffmann &nbsp;·&nbsp; Noë Vallée &nbsp;·&nbsp; Noah Nouvel
    </footer>

</div><!-- /wrap -->

<script>
// ── Horloge temps réel ─────────────────────────────────────────────────────
function updateClock() {
    const now = new Date();
    document.getElementById('clock').textContent =
        now.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    document.getElementById('date-display').textContent =
        now.toLocaleDateString('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
}
setInterval(updateClock, 1000);
updateClock();

// ── Direction → degrés ────────────────────────────────────────────────────
const DIR_DEG = { N:0, NNE:22.5, NE:45, ENE:67.5, E:90, ESE:112.5, SE:135, SSE:157.5,
                  S:180, SSO:202.5, SO:225, OSO:247.5, O:270, ONO:292.5, NO:315, NNO:337.5 };

// ── Échelle de Beaufort ───────────────────────────────────────────────────
function beaufort(kmh) {
    if (kmh === null) return '--';
    if (kmh < 1)   return 'Calme';
    if (kmh < 6)   return 'Très légère brise';
    if (kmh < 12)  return 'Légère brise';
    if (kmh < 20)  return 'Petite brise';
    if (kmh < 29)  return 'Jolie brise';
    if (kmh < 39)  return 'Brise fraîche';
    if (kmh < 50)  return 'Vent frais';
    if (kmh < 62)  return 'Grand frais';
    if (kmh < 75)  return 'Coup de vent';
    if (kmh < 89)  return 'Fort coup de vent';
    if (kmh < 103) return 'Tempête';
    if (kmh < 118) return 'Violente tempête';
    return 'Ouragan';
}

// ── Ressenti thermique (formule Wind Chill / Humidex) ────────────────────
function ressenti(temp, hum) {
    if (temp === null) return '';
    if (temp >= 27 && hum !== null) {
        const humidex = temp + 0.5555 * (6.11 * Math.exp(5417.7530 * (1/273.16 - 1/(273.15 + temp))) * hum/100 - 10);
        return `Ressenti ${humidex.toFixed(1)} °C (humidex)`;
    }
    return '';
}

// ── AQI couleur & libellé ─────────────────────────────────────────────────
function aqiStyle(aqi) {
    if (aqi <= 50)  return { color: '#00c9a7', label: 'Bonne' };
    if (aqi <= 100) return { color: '#fbbf24', label: 'Modérée' };
    if (aqi <= 150) return { color: '#f97316', label: 'Mauvaise pour groupes sensibles' };
    if (aqi <= 200) return { color: '#ef4444', label: 'Mauvaise' };
    return { color: '#9333ea', label: 'Très mauvaise' };
}

// ── Libellé luminosité ────────────────────────────────────────────────────
function luxLabel(lux) {
    if (lux === null) return '--';
    if (lux < 1)    return 'Nuit noire';
    if (lux < 50)   return 'Intérieur sombre';
    if (lux < 500)  return 'Ciel couvert';
    if (lux < 1000) return 'Ciel nuageux';
    if (lux < 5000) return 'Ciel partiellement nuageux';
    if (lux < 20000) return 'Ciel dégagé';
    return 'Plein soleil';
}

// ── Mise à jour de l'interface ─────────────────────────────────────────────
function updateUI(d) {
    const set = (id, val, fallback = '--') =>
        document.getElementById(id).textContent = (val !== null && val !== undefined) ? val : fallback;

    set('temp',     d.temp     !== null ? parseFloat(d.temp).toFixed(1)    : null);
    set('hum',      d.hum      !== null ? parseFloat(d.hum).toFixed(0)     : null);
    set('pression', d.pression !== null ? parseFloat(d.pression).toFixed(0): null);
    set('pluie',    d.pluie    !== null ? parseFloat(d.pluie).toFixed(1)   : null);
    set('vent',     d.vent     !== null ? parseFloat(d.vent).toFixed(1)    : null);
    set('dir',      d.dir);
    set('aqi',      d.aqi);
    set('lux',      d.lux      !== null ? parseInt(d.lux)                  : null);
    set('last-update', d.timestamp);

    // Ressenti
    document.getElementById('temp-feel').textContent = ressenti(d.temp, d.hum);

    // Beaufort
    document.getElementById('vent-beaufort').textContent = beaufort(d.vent);

    // Pression : tendance (simplifiée)
    const p = parseFloat(d.pression);
    let pressTrend = '--';
    if (!isNaN(p)) {
        if (p < 1000) pressTrend = '↓ Dépression — risque de pluie';
        else if (p < 1013) pressTrend = '→ Pression normale';
        else pressTrend = '↑ Anticyclone — beau temps';
    }
    document.getElementById('press-trend').textContent = pressTrend;

    // AQI
    const aqiVal = parseInt(d.aqi);
    if (!isNaN(aqiVal)) {
        const s = aqiStyle(aqiVal);
        document.getElementById('aqi-label').textContent = s.label;
        document.documentElement.style.setProperty('--aqi-color', s.color);
        // Barre AQI (0–200 max affiché)
        const pct = Math.min(aqiVal / 200 * 100, 100);
        document.getElementById('aqi-bar').style.width = pct + '%';
    }

    // Luminosité
    document.getElementById('lux-label').textContent = luxLabel(d.lux !== null ? parseInt(d.lux) : null);

    // Boussole
    const deg = DIR_DEG[d.dir];
    if (deg !== undefined) {
        document.getElementById('compass-needle').style.transform = `rotate(${deg}deg)`;
    }

    // Status dot
    const dot = document.getElementById('status-dot');
    const ts = d.timestamp ? new Date(d.timestamp.replace(' ', 'T')) : null;
    const age = ts ? (Date.now() - ts.getTime()) / 1000 : Infinity;
    dot.className = 'status-dot' + (age > 120 ? ' offline' : '');
}

// ── Fetch data.json toutes les 5 secondes ────────────────────────────────
async function fetchData() {
    try {
        const res = await fetch('data.json?t=' + Date.now()); // cache-bust
        if (!res.ok) throw new Error('HTTP ' + res.status);
        const d = await res.json();
        updateUI(d);
    } catch (e) {
        console.warn('Impossible de récupérer data.json :', e.message);
        document.getElementById('status-dot').className = 'status-dot offline';
    }
}

fetchData();
setInterval(fetchData, 5000);
</script>

</body>
</html>
