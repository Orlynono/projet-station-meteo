

void qualite_air(void)
{
  uint8_t status = ENS160.getENS160Status();
  Serial.print("Status capteur : ");
  Serial.println(status);

  // Attendre que le capteur soit prêt (status == 2 = données valides)
  if (status != 2) {
    Serial.println("⚠️ Capteur pas encore prêt, attente...");
    delay(2000);
    return;  // On relance loop() sans lire les données invalides
  }

  uint8_t AQI = ENS160.getAQI();
  Serial.print("Indice de qualité de l'air (AQI) : ");
  Serial.println(AQI);

  uint16_t TVOC = ENS160.getTVOC();
  Serial.print("TVOC (composés organiques volatils) : ");
  Serial.print(TVOC);
  Serial.println(" ppb");

  uint16_t ECO2 = ENS160.getECO2();
  Serial.print("eCO2 (équivalent CO2) : ");
  Serial.print(ECO2);
  Serial.println(" ppm");

  Serial.println();
  delay(2000);  // 2s recommandé pour laisser le capteur se stabiliser entre lectures
}
