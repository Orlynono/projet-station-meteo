



#include <Wire.h>



// carte uno wifi

#include <SPI.h>
#include <WiFiNINA.h>

#include "arduino_secrets.h"

char ssid[] ="TP_INDUS";        // your network SSID (name)
char pass[] ="3rFui78x";    // your network password (use for WPA, or use as key for WEP)
int keyIndex = 0;                     // your network key index number
int status = WL_IDLE_STATUS;                     // the WiFi radio's status


//******************************************************************************************

//pression
#include <SparkFunMPL3115A2.h>
MPL3115A2 capteurPression;

//******************************************************************************************

//humid et temp
#include <Adafruit_AM2315.h>
Adafruit_AM2315 am2315;

//******************************************************************************************

//girouette
const int WIND_DIR_PIN = A0;
const float R_EXTERNAL = 10000.0;


//******************************************************************************************


//Paramètre capteur lumière
#define address 0x23 //lumiere adresse 23 capteur lumière
uint8_t buf[4] = {0};
uint16_t data;
float Lux;

uint8_t readReg(uint8_t reg, const void* pBuf, size_t size)
{
  if (pBuf == NULL) {
    Serial.println("pBuf ERROR!! : null pointer");
  }
  uint8_t * _pBuf = (uint8_t *)pBuf;
  Wire.beginTransmission(address);
  Wire.write(reg);
  if (Wire.endTransmission() != 0) {
    return 0;
  }
  delay(20);
  Wire.requestFrom((uint8_t)address, (uint8_t)size);
  for (uint16_t i = 0; i < size; i++) {
    _pBuf[i] = Wire.read();
  }
  return size;
}
//******************************************************************************************



//pluviometre
const byte RAIN_PIN = 2;
const float MM_PER_CLICK = 0.2794;
const unsigned long ONE_DAY = 86400000;

volatile unsigned long countRain = 0;
volatile unsigned long lastRainTime = 0;
unsigned long lastResetTime = 0;

void rainISR() {
  unsigned long currentTime = millis();
  if (currentTime - lastRainTime > 50) {
    countRain++;
    lastRainTime = currentTime;
  }
}


//******************************************************************************************


//anemometre
const byte WIND_SPEED_PIN = 3;
const float WIND_FACTOR = 2.4;

volatile unsigned long countWind = 0;
volatile unsigned long lastWindTime = 0;

void windISR()
      {
        unsigned long currentTime = millis();
        if (currentTime - lastWindTime > 50) {
          countWind++;
          lastWindTime = currentTime;
        }
      }



//******************************************************************************************

#include <DFRobot_ENS160.h>//qualiter air 

#define I2C_COMMUNICATION  // Communication I2C. Commentez cette ligne pour utiliser SPI.

#ifdef I2C_COMMUNICATION
  DFRobot_ENS160_I2C ENS160(&Wire, 0x53);
#else
  uint8_t csPin = D3;
  DFRobot_ENS160_SPI ENS160(&SPI, csPin);
#endif

//******************************************************************************************

void setup() 
{
     

     //Initialize serial and wait for port to open:
      Serial.begin(9600);

      // Connexion WiFi module:
              while (!Serial) 
              {
                ; // wait for serial port to connect. Needed for native USB port only
              }
              // check for the WiFi module:
              
              if (WiFi.status() == WL_NO_MODULE)
                  {
                    Serial.println("Communication with WiFi module failed!");
                    // don't continue
                    while (true);
                  }

              String fv = WiFi.firmwareVersion();
              if (fv < WIFI_FIRMWARE_LATEST_VERSION) 
                  {
                    Serial.println("Please upgrade the firmware");
                  }

              // attempt to connect to WiFi network:
              while (status != WL_CONNECTED) 
                  {
                    Serial.print("Attempting to connect to WEP network, SSID: ");
                    Serial.println(ssid);
                    status = WiFi.begin(ssid, keyIndex, pass);

                    // wait 10 seconds for connection:
                    delay(10000);
                  }

                ConnectWithWEP();
                
      //******************************************************************************************
      
      Serial.begin(9600);
      Serial.println("=== GIROUETTE DEMARREE ===");
      Serial.println();//girouette

      //******************************************************************************************

      Wire.begin();
      Serial.println("=== CAPTEUR LUMINOSITE DEMARRE ===");
      Serial.println();//lumiere

      //******************************************************************************************

    
      pinMode(RAIN_PIN, INPUT_PULLUP);
      attachInterrupt(digitalPinToInterrupt(RAIN_PIN), rainISR, FALLING);
      
      lastResetTime = millis();
      
      Serial.println("=== PLUVIOMETRE DEMARRE ===");
      Serial.println();//pluviometre

      //******************************************************************************************

      
      pinMode(WIND_SPEED_PIN, INPUT_PULLUP);
      attachInterrupt(digitalPinToInterrupt(WIND_SPEED_PIN), windISR, FALLING);
      
      Serial.println("=== ANEMOMETRE DEMARRE ===");
      Serial.println();//anemometre

      //******************************************************************************************

      
      #ifdef I2C_COMMUNICATION// qualite air 
        Wire.begin();
      #endif

      // Initialisation ENS160
      while (ENS160.begin() != NO_ERR) {
        Serial.println("Communication avec l'ENS160 impossible, vérifier le câblage.");
        delay(3000);
      }
      Serial.println("Capteur ENS160 initialisé !");

      ENS160.setPWRMode(ENS160_STANDARD_MODE);

      // Délai de stabilisation recommandé après changement de mode
      delay(1000);

      ENS160.setTempAndHum(25.0, 50.0);// qualite air 

      //******************************************************************************************

    // humid et temp
      while (!Serial) {
        delay(10);
      }
      Serial.println("AM2315 Test!");

      if (! am2315.begin()) {
        Serial.println("Sensor not found, check wiring & pullups!");
        while (1);
      }

      delay(2000);
    //******************************************************************************************


    //presion
    Wire.begin();

      // Initialisation sans vérification bool (retourne void)
      capteurPression.begin(Wire, 0x60);

      capteurPression.setModeBarometer();   // Mode pression (Pascals)
      capteurPression.setOversampleRate(7); // Meilleure précision
      capteurPression.enableEventFlags();

      Serial.println("Capteur pression pret !");

}


void loop() {


  pluviometre();  
  anemometre();
  lumiere();
  girouette();
  qualite_air();
  //humid_et_temp();
  pression();
  
}
