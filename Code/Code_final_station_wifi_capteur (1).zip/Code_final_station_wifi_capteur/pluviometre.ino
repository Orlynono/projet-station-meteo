void pluviometre(void) {
  delay(1000);
  
  if (millis() - lastResetTime >= ONE_DAY) {
    float rainMM = countRain * MM_PER_CLICK;
    Serial.println("========================");
    Serial.print(">>> TOTAL DU JOUR: ");
    Serial.print(rainMM, 2);
    Serial.println(" mm <<<");
    Serial.println(">>> Nouveau jour - Reset pluviometre <<<");
    Serial.println("========================");
    countRain = 0;
    lastResetTime = millis();
  }
  
  float rainMM = countRain * MM_PER_CLICK;
  Serial.print("Pluie du jour: ");
  Serial.print(rainMM, 2);
  Serial.print(" mm (");
  Serial.print(countRain);
  Serial.println(" clicks)");
}
