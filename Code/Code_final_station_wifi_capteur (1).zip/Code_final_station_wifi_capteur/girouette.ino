void girouette(void) {
  delay(1000);
  
  int adc = analogRead(WIND_DIR_PIN);
  float voltage = adc * (5.0 / 1023.0);
  float rSensor = (R_EXTERNAL * (5.0 / voltage - 1.0));
  
  Serial.print("Direction: ");
  Serial.print(getDirection(rSensor));
  Serial.print(" (Résistance: ");
  Serial.print(rSensor, 0);
  Serial.println(" Ω)");
}

String getDirection(float r) {
  if (r < 800) return "Sud-Ouest (SO)";
  if (r < 1500) return "Sud (S)";
  if (r < 3000) return "Ouest (O)";
  if (r < 5000) return "Nord-Ouest (NO)";
  if (r < 7500) return "Nord-Est (NE)";
  if (r < 10000) return "Est (E)";
  return "Nord (N)";
}
